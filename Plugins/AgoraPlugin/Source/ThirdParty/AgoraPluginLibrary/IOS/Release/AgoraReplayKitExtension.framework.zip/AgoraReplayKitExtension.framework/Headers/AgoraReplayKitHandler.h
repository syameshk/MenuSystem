//
//  SampleHandler.h
//  BroadCastUI
//
//  Created by Agora on 2022/1/25.
//  Copyright (c) 2022 Agora IO. All rights reserved.

#import <ReplayKit/ReplayKit.h>

API_AVAILABLE(ios(11.0))
@interface AgoraReplayKitHandler : RPBroadcastSampleHandler

@end
