//
//  AgoraScreenShare.h
//  AgoraScreenShare
//
//  Created by Agora on 2022/1/25.
//  Copyright (c) 2022 Agora IO. All rights reserved.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class AgoraRtcEngineKit;
@class AgoraRtcConnection;
@class AgoraScreenCaptureParameters2;
NS_ASSUME_NONNULL_BEGIN
API_AVAILABLE(ios(11.0))
__attribute__((visibility("default")))
@interface AgoraScreenShare : NSObject

- (void)updateRtcEngine:(AgoraRtcEngineKit*)rtcEngine  // NOLINT
             connection:(AgoraRtcConnection* _Nullable)connection;

- (void)startScreenCapture:(AgoraScreenCaptureParameters2* _Nullable)parameters;

- (void)updateScreenCapture:(AgoraScreenCaptureParameters2* _Nullable)parameters;

- (void)stopScreenCapture;

@end

NS_ASSUME_NONNULL_END
